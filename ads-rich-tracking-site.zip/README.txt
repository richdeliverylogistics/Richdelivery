# ads Rich Courier & Logistics

This archive contains the full stack web app (frontend + backend) for the Rich Courier & Logistics tracking system.
Refer to ChatGPT instructions for deployment with Docker or manual setup.

Contact: richdelivery@aol.com
